#ifndef BLINKER_SERVER_H
#define BLINKER_SERVER_H

#define BLINKER_SERVER_HTTPS    "https://iot.diandeng.tech"

#define BLINKER_SERVER_HOST     "iot.diandeng.tech"

#endif