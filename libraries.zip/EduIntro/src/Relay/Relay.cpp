#include "Relay.h"
#include "EduIntro.h"

Relay::Relay(uint8_t _pin) : Output(_pin) {}
